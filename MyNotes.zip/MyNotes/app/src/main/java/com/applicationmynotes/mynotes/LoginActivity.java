package com.applicationmynotes.mynotes;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity {


    private String email;
    private String password;
    private RequestQueue reqQue;
    private SharedPreferences sharedPref;

  //  private CallbackManager callbackManager;
   // private com.facebook.login.widget.LoginButton btnLoginFacebook;

    private static String fEmail;
    private static String fName;
    private static String fSurname;
    private static String fId;

    public int x;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        sharedPref = getSharedPreferences("com.applicationmynotes.mynotes", Context.MODE_PRIVATE);

        reqQue = Volley.newRequestQueue(this);


        findViewById(R.id.btnLogin).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                email    = ((EditText)findViewById(R.id.txtEmail)).getText().toString();
                password = ((EditText)findViewById(R.id.txtPassword)).getText().toString();
                if(email.matches("") ||
                        password.matches("") ){
                    Toast.makeText(getApplicationContext(),"Lütfen Tüm Alanları Doldurun", Toast.LENGTH_LONG).show();
                }
                else{
                     x = 100;
                    sendRequest();
                }
            }
        });


    }
    //region Login Request
    public void sendRequest(){
        String url = Defines.URL_API+"/Login";
        x = 101;
        StringRequest request = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>()
                {
                    @Override
                    public void onResponse(String response) {
                        // response
                        JSONObject jsonObject = null;
                        try {
                             x = 102;
                            jsonObject = new JSONObject(response);
                            //Toast.makeText(getApplicationContext(),jsonObject.getString("message"),Toast.LENGTH_LONG).show();
                            String statu    = jsonObject.getString("statu");
                            String message  = jsonObject.getString("message");


                            if(statu.matches("200")) {
                                String token = jsonObject.getString("token");
                                sharedPref.edit().putString("token",token).apply(); // Shared Yazma


                                Intent mainScreen = new Intent(LoginActivity.this, MainActivity.class);
                                mainScreen.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                startActivity(mainScreen);
                            }
                            else
                                Toast.makeText(getApplicationContext(),message, Toast.LENGTH_LONG).show();

                        } catch (JSONException e) {
                            Log.d("Error.Response", e.getMessage());
                        }
                    }
                },
                new Response.ErrorListener()
                {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        x=102;
                        error.printStackTrace();
                   }
                }
        ) {
            @Override
            protected Map<String, String> getParams()
            {
                Map<String, String>  params = new HashMap<String, String>();
                params.put("email", email);
                params.put("password", password);
                return params;
            }
        };

        reqQue.add(request);
    }
    //endregion



}
