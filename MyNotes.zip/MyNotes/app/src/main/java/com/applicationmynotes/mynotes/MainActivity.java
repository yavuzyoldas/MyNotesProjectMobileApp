package com.applicationmynotes.mynotes;

import androidx.annotation.RequiresPermission;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.sql.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;



public class MainActivity extends AppCompatActivity {

    private String token;
    private SharedPreferences sharedPref;


    private RequestQueue reqQue;

    ArrayList<Notes> notes = new ArrayList<>();

    public int x;
    public String id ;
    public String userid ;
    public String title;
    public String content;
    public String date;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sharedPref = getSharedPreferences("com.applicationmynotes.mynotes", Context.MODE_PRIVATE);
        token = sharedPref.getString("token",null); // Shared Okuma


        reqQue = Volley.newRequestQueue(this);




     /*TextView tv1 = findViewById(R.id.tokenText);
        tv1.setText(token);*/
        if(!token.matches("")){
            sendRequest();
        }


    }
    public void sendRequest(){
        String url = Defines.URL_API+"/MyNotes/get";
        x = 101;
        StringRequest request = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>()
                {
                    @Override
                    public void onResponse(String response) {
                        // response
                        JSONObject jsonObject = null;
                        try {
                            x = 102;
                            jsonObject = new JSONObject(response);
                            //Toast.makeText(getApplicationContext(),jsonObject.getString("message"),Toast.LENGTH_LONG).show();
                            String statu    = jsonObject.getString("statu");
                            String message  = jsonObject.getString("message");
                            JSONArray  data = jsonObject.getJSONArray("data");


                            for(int i = 0; i < data.length();i++) {
                                JSONObject innerObj = data.getJSONObject(i);
                                for(Iterator it = innerObj.keys(); it.hasNext(); ) {
                                    String key = (String)it.next();

                                    System.out.println(key + ":" + innerObj.get(key));
                                   /* if( "id" == key){
                                         id =(String)innerObj.get(key);
                                    }else if("userid" == key){
                                         userid =(String)innerObj.get(key);
                                    }else if("title"==key){
                                         title =(String)innerObj.get(key);
                                    }else if("content"==key){
                                         content =(String)innerObj.get(key);
                                    }else if("date"==key){
                                        date =(String)innerObj.get(key);
                                    }
                                    notes.add(new Notes(id,userid,title,content,date));*/

                                    //System.out.println(Arrays.toString(notes.toArray()));
                                }
                            }





                         //   Log.d("test", Arrays.deepToString(data));

                            //convert List to Array in Java String [] strArray = list.toArray(new String[0]); logger.info("Java List created from JSON String Array - example"); logger.info("JSON String Array : " + jsonStringArray ); logger.info("Java List : " + list); logger.info("String array : " + Arrays.toString(strArray)); // let's now convert Java array to JSON array - String toJson = converter.toJson(list); logger.info("Json array created from Java List : " + toJson);

                          /*  Log.d("Dizi",array);
                            Log.d("id",array["id"])*/
                            if(statu.matches("200")) {
                                String token = jsonObject.getString("token");
                                sharedPref.edit().putString("token",token).apply(); // Shared Yazma

                              /*  for (int i = 0; i < ((JSONArray) data).length(); i++)
                                {

                                }*/
                                /*Intent mainScreen = new Intent(LoginActivity.this, MainActivity.class);
                                mainScreen.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                startActivity(mainScreen);*/
                            }
                            else
                                Toast.makeText(getApplicationContext(),message, Toast.LENGTH_LONG).show();

                        } catch (JSONException e) {
                            Log.d("Error.Response", e.getMessage());
                        }
                    }
                },
                new Response.ErrorListener()
                {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        x = 103;
                        error.printStackTrace();
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams()
            {
                Map<String, String>  params = new HashMap<String, String>();
                params.put("token", token);
                return params;
            }
        };

        reqQue.add(request);
    }











}
