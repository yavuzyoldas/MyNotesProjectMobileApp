package com.applicationmynotes.mynotes;

public class Defines {

        public static final String URL = "http://10.0.2.2/alkosoft";
        //public static final String URL_API = "http://192.168.1.35/mynotes";

        public static final String URL_API = "http://10.7.85.214/mynotes";//saü net
}
